import FormikTextInput from './FormikTextInput';

export default FormikTextInput;

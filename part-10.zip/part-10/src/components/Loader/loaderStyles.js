import { StyleSheet } from 'react-native';

const loaderStyles = StyleSheet.create({
  loader: {
    padding: 10,
  },
});

export default loaderStyles;

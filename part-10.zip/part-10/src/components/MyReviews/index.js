import MyReviews from './MyReviews';

export default MyReviews;

const initialValues = {
  username: '',
  password: '',
  passwordConfirm: '',
};

export default initialValues;

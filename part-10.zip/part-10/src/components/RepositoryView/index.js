import RepositoryView from './RepositoryView';

export default RepositoryView;

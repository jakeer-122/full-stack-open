import { StyleSheet } from 'react-native';

const filtersStyles = StyleSheet.create({
  container: {
    padding: 10,
  },
});

export default filtersStyles;

import RepositoryItem from './RepositoryItem';

export default RepositoryItem;

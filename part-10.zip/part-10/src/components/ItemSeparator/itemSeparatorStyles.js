import { StyleSheet } from 'react-native';

const itemSeparatorStyles = StyleSheet.create({
  separator: {
    height: 10,
  },
});

export default itemSeparatorStyles;

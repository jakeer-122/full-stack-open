import React from 'react';

const AuthStorageContext = React.createContext();

export default AuthStorageContext;

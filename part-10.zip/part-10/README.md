# Exercises for part10 of the [Full Stack Open](https://fullstackopen.com/en/part10) course

It will not work without a server, which you can find at [Github](https://github.com/fullstack-hy2020/rate-repository-api).